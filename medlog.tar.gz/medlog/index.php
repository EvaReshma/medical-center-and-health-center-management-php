<!DOCTYPE html>
<html>

<head>
<style >
    body{

     
        color: black;
        background-image: url("stock1.jpg");
        background-size :cover; 
    }

h1{
  color : brown;
  text-align:center;

}

h3{
  color : black;
  

}



a {

color : black;
background-color : white;
margin : 2px;

}



.check {

  float: right;
}

.user {
 
float: right;
 width:400px;
 height: 300px;




}

</style>

</head>
<body>
<br>

<center>

   <img src="photo.jpg" height="200px" width="200px">
   <img src="flag.png" height="200px" width="400px">
   <img src="5.jpg" height="200px" width="200px">

</center>
<br>
<h1>MEDICAL CENTER</h1>
<center><h2>NATIONAL INSTITUTE OF TECHNOLOGY-CALICUT </h2></center>



<div class="user">

<center><h1> LOG IN </h1>
<form action="password.php" method="post">
  <h3>
<b> Username:</b>
  <input type="text" name="username"><br><br>
<b> Password:</b>
  <input type="password" name="pass"><br><br>

 <input type="submit" value="login" style="font-size: 15pt">
 </center>

</form>
</h3>
</div>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="check">

<a href="http://www.facebook.com/"><img src="Facebook.png" height="50px" width="50px"/></a>
<a href="http://www.gmail.com/"><img src="g-plus.png" height="50px" width="50px"/></a>
<a href="http://www.instagram.com/"><img src="instagram.png" height="50px" width="50px"/></a>
<a href="https://www.twitter.com/"><img src="twitter.png" height="50px" width="50px"/></a>
<a href="http://www.youtube.com/"><img src="youtube.png" height="50px" width="50px"/></a>

</div>
</body>
</html>


