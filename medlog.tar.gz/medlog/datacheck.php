<!DOCTYPE html>
<html>

<head>
<style >
    body{

     
        color: black;
     
        background-size :cover; 
    }

h1{
 color : brown;
text-align:center;

}

a {

color : black;
background-color : white;
margin : 2px;

}

section {
    width:700px;
    float:right;
    padding:10px;
    text-align:center;
}

.check {

  float: right;
}

.check1 {

  float:left;
}



</style>



</head>
<body>
<br>
<div class="check1">
    <a href="enterlec.php"><img src="lec.png" width="70px" height="70px"></a>
  


</div>

<div class="check">
    <a href="enter.php"><img src="add.png" width="70px" height="70px"></a>
    <a href="delete.php"><img src="delete.png" width="70px" height="70px"></a>


</div>



<center>
<div >
   <img src="photo.jpg" height="200px" width="200px">
   <img src="flag.png" height="200px" width="400px">
   <img src="5.jpg" height="200px" width="200px">
</div>
</center>
<br><br>
<h1>MEDICAL CENTER</h1>
<center><h2>NATIONAL INSTITUTE OF TECHNOLOGY-CALICUT </h2></center>
<br><br>



<center>

<a href="dataentry.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="treat2.jpg" height="350px" width="350px"/></a>
<a href="stock.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="stock.jpg" height="350px" width="350px"/></a>
<a href="ward.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="ward1.jpg" height="350px" width="350px"/></a>
<a href="lab.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="lab.jpg" height="350px" width="350px"/></a>
<br><br><br>
<a href="searchdetails.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="treatment.jpg" height="350px" width="350px"/></a>
<a href="storecheck.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="12.jpg" height="350px" width="350px"/></a>
<a href="wardcheck.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="ward2.jpg" height="350px" width="350px"/></a>
<a href="searchlab.php"><img  onmouseover="bigImg(this)" onmouseout="normalImg(this)" border="0" src="labre.jpg" height="350px" width="350px"/></a>

<script>
function bigImg(x) {
    x.style.height = "400px";
    x.style.width = "400px";
}

function normalImg(x) {
    x.style.height = "350px";
    x.style.width = "350px";
}
</script>

</center>
<br><br><br>
<div class="check">
<a href="http://www.facebook.com/"><img src="Facebook.png" height="50px" width="50px"/></a>
<a href="https://www.gmail.com/"><img src="g-plus.png" height="50px" width="50px"/></a>
<a href="http://www.instagram.com/"><img src="instagram.png" height="50px" width="50px"/></a>
<a href="https://www.twitter.com/"><img src="twitter.png" height="50px" width="50px"/></a>
<a href="http://www.youtube.com/"><img src="youtube.png" height="50px" width="50px"/></a>

</div>


</body>
</html>


