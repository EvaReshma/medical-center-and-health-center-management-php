<!DOCTYPE html>
<html>

<head>
<style >
    body{

     
        color: black;
        background-image: url("12345.jpg");
        background-size :cover; 
    }

h1{
  color : brown;
  text-align:center;

}

h3{
  color : black;
  

}

section {
 width:1000px;
 height: 1000px;
 
float: right;

}

a {

color : black;
background-color : white;
margin : 2px;

}



.check {

  float: right;
}

.user {
 
float: right;
 width:500px;
 height: 300px;

padding: 20px;
margin: 2px;

text-align: center;


}

</style>

</head>

<body>
<br>
<section>
<center>

   <img src="photo.jpg" height="200px" width="200px">
   <img src="flag.png" height="200px" width="400px">
   <img src="5.jpg" height="200px" width="200px">

</center>
<br>

<h1>MEDICAL CENTER</h1>
<center><h2>NATIONAL INSTITUTE OF TECHNOLOGY-CALICUT </h2></center>
<br><br>

<h1>LAB DETAILS ENTRY</h1>
<br>

<form action="lab123.php" method="post">
<center>

<b>  Name</b><br>
  <input type="text" name="name" required="true"><br><br>
<b> Roll No</b><br>
  <input type="text" name="rollno" required="true"><br><br>
<b> Test </b><br>
  <input type="text" name="test" required="true"><br><br>
<b> Result</b><br>
  <input type="date" name="result" required="true"><br><br>
<b> Lab Report By  </b><br>
  <input type="text" name="testby" required="true" value="Mrs."><br><br>
<b> Examined by</b><br>
  <input type="text" name="doctor" required="true" value="Dr."><br><br>
  <b>Date</b><br>
  <input type="date" name="date" required="true"><br><br>

<input type='submit' value='SUBMIT' style="font-size: 16pt"><br><br><br>
<br>

  <a href="datacheck.php"><img src="home.png" width="60px" height="60px"></a>
</center>
</form>
</section>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="check">

<a href="http://www.facebook.com/"><img src="Facebook.png" height="50px" width="50px"/></a>
<a href="http://www.gmail.com/"><img src="g-plus.png" height="50px" width="50px"/></a>
<a href="http://www.instagram.com/"><img src="instagram.png" height="50px" width="50px"/></a>
<a href="https://www.twitter.com/"><img src="twitter.png" height="50px" width="50px"/></a>
<a href="http://www.youtube.com/"><img src="youtube.png" height="50px" width="50px"/></a>

</div>
</body>
</html>



