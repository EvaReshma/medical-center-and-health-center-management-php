<!DOCTYPE html>
<html>

<head>
<style >
    body{

     
        color: black;
        background-image: url("12345.jpg");
        background-size :cover; 
    }

h1{
  color : brown;
  text-align:center;

}

h3{
  color : black;
  }


.check {

  float: right;
}

.user {
 
float: right;
 width:500px;
 height: 300px;

padding: 20px;
margin: 2px;

text-align: center;


}

section {
 width:1000px;
 height: 1000px;
 
float: right;

}
</style>

</head>
<body>
<br>
<section>
<center>

   <img src="photo.jpg" height="200px" width="200px">
   <img src="flag.png" height="200px" width="400px">
   <img src="5.jpg" height="200px" width="200px">

</center>
<br>

<h1>MEDICAL CENTER</h1>
<center><h2>NATIONAL INSTITUTE OF TECHNOLOGY-CALICUT </h2></center>
<br><br>

<h1>Staff Entry</h1>
<br>
<center>
<form action="enterlec123.php" method="post">
<b> NAME</b><br>
  <input type="text" name="name" required="true"><br><br>
<b> SSN</b><br>
  <input type="text" name="rollno" required="true"><br><br>
  <b>DEPARTMENT </b><br>
  <input type="text" name="department" required="true"><br><br>
   <b>EDUCATION QUALIFICATION </b><br>
  <input type="text" name="course" required="true"><br><br>
  <b> ADDRESS</b><br>
  <input type="text" name="address" required="true"><br><br>
  <b>MOBILE NO</b><br>
  <input type="text" name="mobile" maxlength="10" required="true"><br><br>
   <b> E-MAIL  </b><br>
  <input type="email" name="email" required="true"><br><br>
      <b> DEPENDENT-1 (spause)  </b>
  <input type="text" name="dep1"> <br><br>
     <b> DEPENDENT-2 (child1) </b>
  <input type="text" name="dep2"><br><br>
      <b> DEPENDENT-3 (child2) </b>
  <input type="text" name="dep3"><br><br>
      <b> DEPENDENT-4 (Parents) </b>
  <input type="text" name="dep4"><br><br>
   

  <input type="submit" value="New-lec" style="font-size: 16pt" ><br><br>
</center>
</form>
<center><a href="datacheck.php"><img src="home.png" width="60px" height="60px"></a></center>

</section>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="check">

<a href="http://www.facebook.com/"><img src="Facebook.png" height="50px" width="50px"/></a>
<a href="http://www.gmail.com/"><img src="g-plus.png" height="50px" width="50px"/></a>
<a href="http://www.instagram.com/"><img src="instagram.png" height="50px" width="50px"/></a>
<a href="https://www.twitter.com/"><img src="twitter.png" height="50px" width="50px"/></a>
<a href="http://www.youtube.com/"><img src="youtube.png" height="50px" width="50px"/></a>

</div>
</body>
</html>



