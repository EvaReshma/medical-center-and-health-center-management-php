<!DOCTYPE html>
<html>

<head>
<style >
    body{

     
        color: black;
        background-image: url("12345.jpg");
        background-size :cover; 
    }

h1{
  color : brown;
  text-align:center;

}

h2{

  color:purple;
}

h3{
  color : black;
  }


section {
 width:900px;
 height: 1000px;
 float: right;

}




.check {

  float: right;
}

.user {
 
float: right;
 width:500px;
 height: 300px;
padding: 20px;
margin: 2px;
text-align: center;


}

</style>

</head>
<body>
<br>
<section>
<center>

   <img src="photo.jpg" height="200px" width="200px">
   <img src="flag.png" height="200px" width="400px">
   <img src="5.jpg" height="200px" width="200px">

</center>
<br>
<h1>MEDICAL CENTER</h1>
<center><h2 style="color: brown">NATIONAL INSTITUTE OF TECHNOLOGY-CALICUT </h2></center>
<br><br>
<center><h2>WARD ENTRY</h2></center>
<br>
<center>
<form action="ward123.php" method="post">


<b>  Name</b><br>
  <input type="text" name="name" required="true"><br><br>
<b> Roll No</b><br>
  <input type="text" name="rollno" required="true"><br><br>
<b> Disease </b><br>
  <input type="text" name="disease" required="true"><br><br>
<b> Admitted On</b><br>
  <input type="date" name="admit" required="true"><br><br>
<b> Examined by</b><br>
  <input type="date" name="doctor" required="true" value="Dr."><br><br>
<input type='submit' value='SUBMIT' style="font-size: 16pt"><br><br>
 
  
</form>
  <br><br>

 <form action=123.php method="post">
  <h2>Discharge</h2><br><br>
 <b> patient id </b><br>
 <input type="text" name="dis" required="true"><br><br>
  <b> Admitted On </b><br>
 <input type="date" name="dateadmit" required="true">
 <br><br>
   <b> Discharged On </b><br>
 <input type="date" name="discharge" required="true">
 <br><br>
 <input type="submit" value="discharge" style="font-size: 16pt"><br><br>
 
<a href="datacheck.php"><img src="home.png" width="60px" height="60px"></a>
</form>


</center>
</section>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="check">

<a href="http://www.facebook.com/"><img src="Facebook.png" height="50px" width="50px"/></a>
<a href="http://www.gmail.com/"><img src="g-plus.png" height="50px" width="50px"/></a>
<a href="http://www.instagram.com/"><img src="instagram.png" height="50px" width="50px"/></a>
<a href="https://www.twitter.com/"><img src="twitter.png" height="50px" width="50px"/></a>
<a href="http://www.youtube.com/"><img src="youtube.png" height="50px" width="50px"/></a>

</div>
</body>
</html>



