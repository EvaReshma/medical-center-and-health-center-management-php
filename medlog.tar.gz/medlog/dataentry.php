<!DOCTYPE html>
<html>

<head>
<style >
    body{

     
        color: black;
        background-image: url("12345.jpg");
        background-size :cover; 
    }

h1{
  color : brown;
  text-align:center;

}

h3{
  color : black;
  

}



a {

color : black;
background-color : white;
margin : 2px;

}



.check {

  float: right;
}

.user {
 
float: right;
 width:500px;
 height: 300px;

padding: 20px;
margin: 2px;

text-align: center;


}

section {
 width:1000px;
 height: 1000px;
 
float: right;

}
</style>

</head>
<body>
<br>
<section>
<center>

   <img src="photo.jpg" height="200px" width="200px">
   <img src="flag.png" height="200px" width="400px">
   <img src="5.jpg" height="200px" width="200px">

</center>
<br>

<h1>MEDICAL CENTER</h1>
<center><h2>NATIONAL INSTITUTE OF TECHNOLOGY-CALICUT </h2></center>
<br><br>

<h1>TREATMENT ENTRY</h1>
<br>

<center>

<form action="dataentry2.php" method="post">

<b> NAME</b><br>
  <input type="text" name="name"><br><br>
<b> ROLL NO</b><br>
  <input type="text" name="rollno"><br><br>
<b>  DATE</b><br>
  <input type="date" name="date"><br><br>
<b> DISEASE</b><br>
  <input type="text" name="disease"><br><br>
<b> MEDICINE </b><br><br>
<b> TABLETS 1 </b>
  <input type="text" name="medicinetab1">
<b> QTY </b>
  <input type="text" name="quantity1" value="0"><br>
<b> TABLETS 2 </b>
  <input type="text" name="medicinetab2">
<b> QTY </b>
  <input type="text" name="quantity2" value="0"><br>
<b> TABLETS 3 </b>
  <input type="text" name="medicinetab3">
<b> QTY </b>
  <input type="text" name="quantity3" value="0"><br>
<b> TABLETS 4</b>
  <input type="text" name="medicinetab4">
<b> QTY </b>
  <input type="text" name="quantity4" value="0"><br>
<b> SYRUP  </b>
  <input type="text" name="medicinetab5">
<b> QTY </b>
  <input type="text" name="quantity5" value="0"><br><br>
<b> EXAMINED BY</b><br>
  <input type="text" name="checkeddoctor" value="Dr."><br><br>
   <input type='submit' value='submit' style="font-size: 16pt"><br><br>
</center>
</form>
<center> <a href="datacheck.php"><img src="home.png" width="60px" height="60px"></a></center>

</section>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="check">

<a href="http://www.facebook.com/"><img src="Facebook.png" height="50px" width="50px"/></a>
<a href="http://www.gmail.com/"><img src="g-plus.png" height="50px" width="50px"/></a>
<a href="http://www.instagram.com/"><img src="instagram.png" height="50px" width="50px"/></a>
<a href="https://www.twitter.com/"><img src="twitter.png" height="50px" width="50px"/></a>
<a href="http://www.youtube.com/"><img src="youtube.png" height="50px" width="50px"/></a>
</div>
</body>
</html>



